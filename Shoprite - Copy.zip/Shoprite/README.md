# 🛒 Shoprite — Final POE Submission (Parts 1–3)

This repository contains the complete **Shoprite website project** developed across **Parts 1, 2, and 3**.
The website maintains the original layout and structure from previous submissions while incorporating all the **required improvements, corrections, and additional features** for Part 3.

## ✅ Summary of Changes and Additions (Part 3)

* **Root Directory Update**
  The project folder has been renamed to **Shoprite**, aligning with the feedback from Part 2 to ensure the root directory reflects the business organization’s name.
  This helps maintain consistency, professionalism, and clear project structure.

* **Wireframes**
  Added ** wireframes** for all main pages (Home, About, Products, Enquiry, and Contact) located in `Documentation/Wireframes/`.
  These were missing in Part 2 and are now included as required by the rubric.

* **Forms and Validation**
  Both **Contact** and **Enquiry** forms now include **client-side validation** (in `js/forms.js`).
  Validation checks include:

  * Full name (minimum 2 characters)
  * Valid email format
  * Message length (minimum 10 characters)
    Clear error messages are displayed if validation fails.

* **Form Submission**
  Forms are configured for **Formspree integration**.
  To enable actual email delivery, add a Formspree endpoint using the `data-formspree` attribute or the `action` attribute, for example:

  ```html
  data-formspree="https://formspree.io/f/yourFormID"
  ```

* **Map Integration**
  The **Contact page** includes **interactive Google Maps** displaying the Shoprite Head Office (Johannesburg) and branches in **Cape Town** and **Durban**.
  Users can click *“View larger map”* to see full interactive details — fulfilling the interactive website requirement.

* **Social Media Integration**
  Added **social media icons and links** in the website footer to promote engagement and connectivity.
  The following platforms were added using PNG icons stored in `images/`:

  * Facebook → [facebook.com/shopriteSA](https://www.facebook.com/shopriteSA)
  * Instagram → [instagram.com/shopritesa](https://www.instagram.com/shopritesa/)
  * WhatsApp → [wa.me/27600123456](https://wa.me/27600123456)

This project uses advanced DOM manipulation to dynamically display product categories and items on the product page, allowing content to update instantly without reloading the page. A product gallery is also included at the bottom of the page, showing all images in equal sizes for a neat layout. Each image can be clicked to open a lightbox, where the user can view a larger version and navigate using arrows. This improves interactivity and enhances the overall user experience.

* **Dynamic Products, Search & Sort (Task 2.2)**
  The **Products page** (`products.html`) now features **dynamic product loading, search, and sort functionality**:

  1. **Product Data Array**
     All products are stored in a **JavaScript array** with properties:

     * `id` → unique identifier
     * `title` → product name
     * `description` → short info
     * `img` → image path
     * `link` → destination page

  2. **Dynamic Rendering**
     JavaScript loops through the array and generates HTML **product cards** automatically, allowing new products to be added without editing HTML.

  3. **Real-Time Search**

     * Users type keywords in the **search bar**.
     * The script filters the product array to show only matching results (search matches both name and description).
     * If no products match, a message **“No products found”** appears.

  4. **Sort Functionality**

     * Users can sort products alphabetically using a **dropdown menu**.
     * Options include **A → Z** and **Z → A**.
     * Sorting works on the **filtered results** if a search is active.

  5. **Responsive Display**
     The product cards are styled with **flexbox**, ensuring proper alignment across desktop and mobile views.

* **About Page Updates**

  * Removed the external **Shoprite website link** from the About page to prevent navigation errors.
  * Expanded the **“Our History”** section with additional information:

    > The company Shoprite was established in 1979 in Cape Town, South Africa, with an aspiration to provide groceries at a low cost without sacrificing quality. Following rapid growth, by 1986, the company was listed on the Johannesburg Stock Exchange. In 1990, the company entered the first phase of its international expansion after opening a store in Windhoek, Namibia. The company's second phase of international expansion occurred in 1991 upon acquiring the Checkers supermarket chain, which helped solidify its position in the retail market. The fully integrated Shoprite chain along with Checkers growth was followed in later years by several new formats, such as Usave, to cater to the budget conscious shopper, and Shoprite LiquorShop opened to allow liquor sales. Over the years, this company has continued its growth in many African economies, including entering Angola and other countries; as of 2013, Shoprite owned over 1000 supermarkets. One of the priorities of Shoprite today is to continue to expand to more stores in Africa. The company is well known to deliver its customers great value product lines through affordable private-label products as well as a number of great service offerings. The company is also known for a tremendous leadership team that provides a valuable vision for customers and their vision has crafted a very successful supermarket retail chain.

* **SEO & Accessibility Improvements**
  Reviewed and optimized for **On-Page SEO**, including: keywords, titles, meta descriptions, headings, image alt text, URL structure, internal linking, and mobile responsiveness.

* **Documentation & Evidence**
  Added `Documentation/Screenshots/` containing desktop and mobile screenshots as evidence for PoE submission.
  Included updated **README.md** and **CHANGELOG.md** for submission clarity and progress tracking.

* **Design Preservation**
  The original visual layout, design, and structure remain unchanged.
  All updates are functional and accessibility-focused to meet rubric standards while maintaining the original design integrity.

GitHub.
	•	Added homepage, product/gallery page, about page, and contact form.
	•	Included responsive layout and basic styling.
	•	Added README file with project information.

Version 1.1 – Updates
	•	Improved navigation links.
	•	Updated product gallery images.
	•	Fixed form validation issue.
	•	Cleaned up CSS for better structure.



✅ REFERENCE SECTION

References
	•	GitHub, 2025. GitHub Documentation: Creating and Managing Repositories. Available at: https://docs.github.com (Accessed 20 November 2025).
	•	W3Schools, 2025. HTML & CSS Tutorials. Available at: https://www.w3schools.com (Accessed 20 November 2025).


