# CHANGELOG - Shoprite Website POE

* Preserved original website layout and content from previous submissions (no design changes).
* Added wireframes for Home, Products, Services, About, Contact, and Enquiry pages in `Documentation/Wireframes/`.
* Implemented client-side validation for Contact and Enquiry forms (`js/forms.js`) including name, email, and message length checks.
* Prepared forms for Formspree AJAX submission (`data-formspree` attribute or form `action`).
* Added interactive Google Maps to Contact page for Johannesburg, Cape Town, and Durban locations.
* Inserted meta descriptions for all pages to improve SEO.
* Added `robots.txt` and a basic `sitemap.xml` for search engine indexing.
* Ensured all images have `alt` attributes for accessibility.
* Added `Documentation/Screenshots` containing desktop and mobile evidence images for PoE.
* Added `js/script.js` to handle navigation toggling and lazy-loading attributes.
* Updated About page history section with detailed Shoprite history content and removed the external link.
* README updated with instructions, testing steps, and additional history information.
GitHub.
	•	Added homepage, product/gallery page, about page, and contact form.
	•	Included responsive layout and basic styling.
	•	Added README file with project information.

Version 1.1 – Updates
	•	Improved navigation links.
	•	Updated product gallery images.
	•	Fixed form validation issue.
	•	Cleaned up CSS for better structure.

⸻

✅ REFERENCE SECTION

References
	•	GitHub, 2025. GitHub Documentation: Creating and Managing Repositories. Available at: https://docs.github.com (Accessed 20 November 2025).
	•	W3Schools, 2025. HTML & CSS Tutorials. Available at: https://www.w3schools.com (Accessed 20 November 2025).


