====================== HEADER (RED) =====================
Page Title: Shoprite Enquiry
Navigation: Home | About Us | What We Offer | Enquiry | Contact
=======================================================

=================== SUBMIT YOUR FORM ===================
Title: Submit Your Form
Description: "If you have questions about our products, services, or need assistance, please fill out the form below and we'll get back to you as soon as possible."
=======================================================

=================== ENQUIRY FORM =======================
Form Fields:
- Full Name: [______________]
- Email Address: [______________]
- Phone Number (Optional): [______________]
- Inquiry Type: 
  [ Select Type of Inquiry ▼ ]
    Options: 
      - Product
      - Service
      - Feedback
      - Other
- Message: [_________________________]

Button: [ Red Submit Inquiry Button ]
=======================================================

========================= FOOTER ======================
© 2025 Shoprite. All Rights Reserved.
Links: Contact Us | Facebook | Instagram | WhatsApp
Images/Icons: Encircled images for social links
=======================================================
