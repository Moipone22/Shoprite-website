# ABOUT PAGE — WIREFRAME

-----------------------------------------------------
|                     HEADER                         |
|  [Shoprite Title]                           |
|  ------------------------------------------------  |
|  Home | About Us | What We Offer | Enquiry | Contact Us |
-----------------------------------------------------

---------------------- PAGE TITLE --------------------
                     ABOUT SHOPRITE
-----------------------------------------------------

---------------------- OUR HISTORY -------------------
|  Section Heading: Our History                       |
|  Paragraph describing:                               |
|   - When Shoprite started                            |
|   - What the company does                            |
|   - Growth and expansion                             |
-------------------------------------------------------

----------------------- OUR MISSION -------------------
|  Section Heading: Our Mission                        |
|  Paragraph describing the mission                    |
-------------------------------------------------------

------------------------ OUR VISION -------------------
|  Section Heading: Our Vision                         |
|  Paragraph describing the vision                     |
-------------------------------------------------------

------------- FUN FACTS & ACHIEVEMENTS ---------------
|   [ Block 1 ]     |   [ Block 2 ]     |   [ Block 3 ] |
| Over 2,800 Stores | Award-Winning     | Millions Served |
|                   | Retailer          | Daily           |
-------------------------------------------------------

------------------------ MEET OUR TEAM ----------------
|  TEAM MEMBER CARDS                                   |
|  --------------------------------------------------  |
|  [Image]  CEO: John Doe                              |
|  [Image]  COO: Jane Smith                            |
|  [Image]  Marketing Director: Michael Brown          |
--------------------------------------------------------

-------------------------- FOOTER ----------------------
|  © 2025 Shoprite. All Rights Reserved.               |
|  Contact Us | Facebook | Instagram | WhatsApp        |
--------------------------------------------------------


