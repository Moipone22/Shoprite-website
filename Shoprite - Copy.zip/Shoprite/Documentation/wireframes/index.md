===================== HEADER (RED) =====================
Page Title: RICHTON – Welcome to Shoprite
Navigation: Home | About Us | What We Offer | Enquiry | Contact
=======================================================

===================== HERO SECTION =====================
[Full-width hero banner image]

Headline: "Your One-Stop Grocery Store"
Subtext: "Affordable prices, quality products, and excellent service making everyday life easier for families across Africa."
[Red Button: SHOP NOW]
=======================================================

=================== CATEGORY / FEATURE BOXES ==========
[Fresh Groceries]
- Description: High-quality fruits and daily essentials at unbeatable prices

[Exclusive Deals]
- Description: Special discounts and promotions every week for our valued customers

[Fast Delivery]
- Description: Order online and receive your groceries quickly and safely at home
=======================================================

========================= FOOTER =====================
© 2025 Shoprite. All Rights Reserved.
Links: Contact Us | Facebook | Instagram | WhatsApp
=======================================================
