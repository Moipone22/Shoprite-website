====================== HEADER (RED) =====================
Page Title: Shoprite Products & Services
Navigation: Home | About Us | What We Offer | Enquiry | Contact
=======================================================

==================== OUR OFFERINGS =====================
Title: "Our Offerings"
Paragraph: "ShopRite provides a wide range of groceries, household items, and additional services to make shopping convenient, affordable, and enjoyable for families across Africa."
=======================================================

==================== SEARCH PRODUCTS ===================
Input Box: [ Search for groceries, snacks, household items... ]
=======================================================

===================== SORT DROPDOWN ===================
Label: Sort By:
Dropdown Options: Default | Name A → Z | Name Z → A
=======================================================

==================== CATEGORY CARDS ===================
[Groceries] 
- Products Available: 4
- Image: (Represents groceries)
- Button: View More

[Household Essentials] 
- Products Available: 3
- Image: (Represents household items)
- Button: View More

[Beverages & Snacks] 
- Products Available: 3
- Image: (Represents beverages & snacks)
- Button: View More

[Additional Services] 
- Products Available: 1
- Image: (Represents delivery/service)
- Button: View More
=======================================================

==================== CATEGORY DETAIL VIEW =============
--- Groceries ---
Products: Apples | Bananas | Milk | Bread
Button: Back to Categories

--- Household Essentials ---
Products: Detergent | Dish Soap | Trash Bags
Button: Back to Categories

--- Beverages & Snacks ---
Products: Coke | Chips | Juice
Button: Back to Categories

--- Additional Services ---
Products: Delivery
Button: Back to Categories
=======================================================

========================= FOOTER ======================
© 2025 Shoprite. All Rights Reserved.
Links: Contact Us | Facebook | Instagram | WhatsApp
=======================================================
