====================== HEADER (RED) =====================
Page Title: Shoprite Contact Us
Navigation: Home | About Us | What We Offer | Enquiry | Contact
=======================================================

==================== LOCATIONS =========================
[Location Block 1]
Header: Head Office
Company: Shoprite Holdings LTD
Address:1B Melrose, Boulevard, Johannesburg, South Africa
Phone: +27 11 290 9000
Map: Embedded map
Button: View Larger Map

[Location Block 2]
Header: Shoprite Cape Town
Company: Shoprite Canal Walk
Address: Century City, Boulevard, Cape Town, South Africa
Phone: +27 21 530 9700
Map: Embedded map
Button: View Larger Map

[Location Block 3]
Header: Shoprite Durban
Company: Shoprite Gateway
Address: Theatre of Shopping, Umhlanga, Durban, South Africa
Phone: +27 31 566 3500
Map: Embedded map
Button: View Larger Map
=======================================================

==================== SEND US A MESSAGE FORM ============
Title: Send Us a Message

Form Fields:
- Full Name: [______________]
- Email Address: [______________]
- Phone Number (Optional): [______________]
- Message: [_________________________]

Button: [ Red Submit Message Button ]
=======================================================

========================= FOOTER ======================
© 2025 Shoprite. All Rights Reserved.
Links: Contact Us | Facebook | Instagram | WhatsApp
Images/Icons: Encircled images for social links
=======================================================
