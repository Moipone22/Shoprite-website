document.addEventListener("DOMContentLoaded", () => {

  // ==============================
  // HELPER FUNCTION: AJAX SUBMIT
  // ==============================
  async function ajaxSubmit(form, endpoint, resultEl) {
    const fd = new FormData(form);
    try {
      resultEl.textContent = "Sending...";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Accept": "application/json" },
        body: fd
      });
      if (res.ok) {
        resultEl.textContent = "Message sent — thank you!";
        form.reset();
        return true;
      } else {
        const json = await res.json();
        resultEl.textContent = json.error || "Error sending message";
        return false;
      }
    } catch (e) {
      resultEl.textContent = "Could not send — please try again later.";
      return false;
    }
  }

  // ==============================
  // ENQUIRY FORM
  // ==============================
  const enquiryForm = document.getElementById("enquiryForm");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // Fields
      const fullname = document.getElementById("fullname");
      const email = document.getElementById("email");
      const phone = document.getElementById("phone");
      const subject = document.getElementById("subject");
      const message = document.getElementById("message");

      // Result container
      let resultEl = document.getElementById("enquiryResponse");
      if (!resultEl) {
        resultEl = document.createElement("div");
        resultEl.id = "enquiryResponse";
        enquiryForm.insertAdjacentElement("afterend", resultEl);
      }
      resultEl.textContent = "";

      // Validation
      let errors = [];
      if (!fullname.value.trim()) errors.push("Full Name is required.");
      if (!email.value.trim()) errors.push("Email is required.");
      else if (!/^\S+@\S+\.\S+$/.test(email.value.trim())) errors.push("Email format invalid.");
      if (phone.value.trim() && !/^\+?\d{10,15}$/.test(phone.value.trim())) errors.push("Phone format invalid (10-15 digits).");
      if (!subject.value) errors.push("Please select an enquiry type.");
      if (!message.value.trim()) errors.push("Message cannot be empty.");
      else if (message.value.trim().length < 10) errors.push("Message must be at least 10 characters.");

      if (errors.length > 0) {
        resultEl.innerHTML = errors.join("<br>");
        resultEl.style.color = "red";
        return;
      }

      // Custom response based on enquiry type
      let responseText = "";
      switch(subject.value) {
        case "product":
          responseText = `Thank you ${fullname.value}, we will check product availability and respond to ${email.value}.`;
          break;
        case "service":
          responseText = `Thank you ${fullname.value}, our team will review your service enquiry and reply to ${email.value}.`;
          break;
        case "feedback":
          responseText = `Thanks for your feedback, ${fullname.value}! We appreciate your input.`;
          break;
        default:
          responseText = `Thank you ${fullname.value}, your enquiry has been received.`;
      }

      // AJAX submit to Formspree (replace yourFormID)
      const endpoint = enquiryForm.dataset.formspree || enquiryForm.getAttribute("action") || "https://formspree.io/f/yourFormID";
      ajaxSubmit(enquiryForm, endpoint, resultEl).then(success => {
        if (success) resultEl.style.color = "green";
        else resultEl.style.color = "red";
      });
    });
  }

  // ==============================
  // CONTACT FORM
  // ==============================
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // Fields
      const fullname = document.getElementById("fullnameContact");
      const email = document.getElementById("emailContact");
      const phone = document.getElementById("phoneContact");
      const message = document.getElementById("messageContact");

      // Result container
      let resultEl = document.getElementById("contactResult");
      if (!resultEl) {
        resultEl = document.createElement("div");
        resultEl.id = "contactResult";
        contactForm.insertAdjacentElement("afterend", resultEl);
      }
      resultEl.textContent = "";

      // Validation
      let errors = [];
      if (!fullname.value.trim()) errors.push("Full Name is required.");
      if (!email.value.trim()) errors.push("Email is required.");
      else if (!/^\S+@\S+\.\S+$/.test(email.value.trim())) errors.push("Email format invalid.");
      if (phone.value.trim() && !/^\+?\d{10,15}$/.test(phone.value.trim())) errors.push("Phone format invalid (10-15 digits).");
      if (!message.value.trim()) errors.push("Message cannot be empty.");
      else if (message.value.trim().length < 10) errors.push("Message must be at least 10 characters.");

      if (errors.length > 0) {
        resultEl.innerHTML = errors.join("<br>");
        resultEl.style.color = "red";
        return;
      }

      // Compile email content (for demo/logging)
      const emailContent = `
        To: shoprite@example.com
        Subject: Contact Form Message
        From: ${fullname.value} <${email.value}>
        Phone: ${phone.value}
        
        Message:
        ${message.value}
      `;
      console.log(emailContent); // replace with backend to actually send

      // AJAX submit to Formspree (replace yourFormID)
      const endpoint = contactForm.dataset.formspree || contactForm.getAttribute("action") || "https://formspree.io/f/yourFormID";
      ajaxSubmit(contactForm, endpoint, resultEl).then(success => {
        resultEl.style.color = success ? "green" : "red";
        if(success) resultEl.textContent = `Thank you ${fullname.value}, your message has been sent!`;
      });
    });
  }
});
// ==============================
// Advanced Lightbox with navigation
// ==============================
document.addEventListener("DOMContentLoaded", () => {
  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightbox-img");
  const caption = document.getElementById("lightbox-caption");
  const closeBtn = document.querySelector("#lightbox .close");
  const prevBtn = document.querySelector("#lightbox .prev");
  const nextBtn = document.querySelector("#lightbox .next");

  const images = Array.from(document.querySelectorAll(".product img"));
  let currentIndex = 0;

  function openLightbox(index) {
    currentIndex = index;
    lightbox.style.display = "block";
    lightboxImg.src = images[index].src;
    caption.textContent = images[index].alt;
  }

  function closeLightbox() {
    lightbox.style.display = "none";
  }

  function showPrev() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    lightboxImg.src = images[currentIndex].src;
    caption.textContent = images[currentIndex].alt;
  }

  function showNext() {
    currentIndex = (currentIndex + 1) % images.length;
    lightboxImg.src = images[currentIndex].src;
    caption.textContent = images[currentIndex].alt;
  }

  images.forEach((img, index) => {
    img.addEventListener("click", () => openLightbox(index));
  });

  closeBtn.addEventListener("click", closeLightbox);
  lightbox.addEventListener("click", e => {
    if (e.target === lightbox) closeLightbox();
  });

  prevBtn.addEventListener("click", e => {
    e.stopPropagation();
    showPrev();
  });

  nextBtn.addEventListener("click", e => {
    e.stopPropagation();
    showNext();
  });

  // Optional: Keyboard support
  document.addEventListener("keydown", e => {
    if (lightbox.style.display === "block") {
      if (e.key === "ArrowLeft") showPrev();
      else if (e.key === "ArrowRight") showNext();
      else if (e.key === "Escape") closeLightbox();
    }
  });
});
