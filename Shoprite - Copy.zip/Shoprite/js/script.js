document.addEventListener("DOMContentLoaded", () => {

  // ==============================
  // PRODUCTS DATA
  // ==============================
  const products = [
    {
      id: "groceries",
      name: "Groceries",
      items: [
        {title: "Apples", image: "images/IMG_0341.JPG", desc: "Fresh red apples."},
        {title: "Bananas", image: "images/bananas.webp", desc: "Organic bananas."},
        {title: "Milk", image: "images/milk.webp", desc: "Fresh dairy milk."},
        {title: "Bread", image: "images/bread.webp", desc: "Whole wheat bread."}
      ]
    },
    {
      id: "household",
      name: "Household Essentials",
      items: [
        {title: "Detergent", image: "images/detergent.jpg", desc: "Powerful laundry detergent."},
        {title: "Dish Soap", image: "images/dish washing liquid.jpg", desc: "Gentle on hands."},
        {title: "Trash Bags", image: "images/trash bags.jpg", desc: "Durable trash bags."}
      ]
    },
    {
      id: "beverages",
      name: "Beverages & Snacks",
      items: [
        {title: "Coke", image: "images/IMG_0348.jpg", desc: "Classic soft drink."},
        {title: "Chips", image: "images/chips.JPG", desc: "Crispy potato chips."},
        {title: "Juice", image: "images/juice.JPG", desc: "Fresh fruit juice."}
      ]
    },
    {
      id: "services",
      name: "Additional Services",
      items: [
        {title: "Delivery", image: "images/delivery.jpg", desc: "Fast Sixty60 delivery."}
      ]
    }
  ];

  const container = document.getElementById("productsContainer");
  const searchBox = document.getElementById("productSearch");
  const sortDropdown = document.getElementById("sortProducts");
  let currentCategoryId = null;

  // ==============================
  // DISPLAY CATEGORIES
  // ==============================
  function displayCategories(list = products) {
    container.innerHTML = "";
    currentCategoryId = null;

    list.forEach(cat => {
      const div = document.createElement("div");
      div.classList.add("product");
      div.innerHTML = `
        <img src="${cat.items[0].image}" alt="${cat.name}">
        <h3>${cat.name}</h3>
        <p>${cat.items.length} products available</p>
        <a href="#" class="view-more" data-id="${cat.id}">View More</a>
      `;
      container.appendChild(div);
    });

    document.querySelectorAll(".view-more").forEach(btn => {
      btn.addEventListener("click", e => {
        e.preventDefault();
        currentCategoryId = btn.dataset.id;
        displayCategoryItems(currentCategoryId);
      });
    });
  }

  // ==============================
  // DISPLAY CATEGORY ITEMS
  // ==============================
  function displayCategoryItems(catId) {
    const category = products.find(c => c.id === catId);
    let itemsToShow = [...category.items];

    // Sort items
    const sortValue = sortDropdown.value;
    if(sortValue === "az") itemsToShow.sort((a,b) => a.title.localeCompare(b.title));
    else if(sortValue === "za") itemsToShow.sort((a,b) => b.title.localeCompare(a.title));

    container.innerHTML = `<h2>${category.name}</h2><a href="#" id="backBtn">← Back to categories</a>`;
    const grid = document.createElement("div");
    grid.classList.add("products");

    itemsToShow.forEach(item => {
      const div = document.createElement("div");
      div.classList.add("product");
      div.innerHTML = `
        <img src="${item.image}" alt="${item.title}">
        <h3>${item.title}</h3>
        <p>${item.desc}</p>
        <a href="#">Shop Now</a>
      `;
      grid.appendChild(div);
    });

    container.appendChild(grid);

    document.getElementById("backBtn").addEventListener("click", e => {
      e.preventDefault();
      displayCategories();
    });
  }

  // ==============================
  // SEARCH
  // ==============================
  searchBox.addEventListener("input", () => {
    const query = searchBox.value.toLowerCase();
    const filtered = products.filter(cat =>
      cat.name.toLowerCase().includes(query) ||
      cat.items.some(item => item.title.toLowerCase().includes(query))
    );
    displayCategories(filtered);
  });

  // ==============================
  // SORT
  // ==============================
  sortDropdown.addEventListener("change", () => {
    if(currentCategoryId) displayCategoryItems(currentCategoryId);
    else {
      let sorted = [...products];
      if(sortDropdown.value === "az") sorted.sort((a,b) => a.name.localeCompare(b.name));
      else if(sortDropdown.value === "za") sorted.sort((a,b) => b.name.localeCompare(a.name));
      displayCategories(sorted);
    }
  });

  displayCategories();

  // ==============================
  // DYNAMIC GALLERY WITH LIGHTBOX
  // ==============================
  const gallery = document.getElementById("gallery");

  // Flatten all products for gallery
  const allItems = products.flatMap(cat => cat.items);

  allItems.forEach(item => {
    const img = document.createElement("img");
    img.src = item.image;
    img.alt = item.title;
    gallery.appendChild(img);
  });

  // Create overlay elements for lightbox
  const overlay = document.createElement("div");
  overlay.id = "lightboxOverlay";
  overlay.innerHTML = `<span id="closeLightbox">&times;</span><img id="lightboxImage" src="" alt="Enlarged Product">`;
  document.body.appendChild(overlay);

  const lightboxImage = overlay.querySelector("#lightboxImage");
  const closeBtn = overlay.querySelector("#closeLightbox");

  gallery.querySelectorAll("img").forEach(img => {
    img.addEventListener("click", () => {
      overlay.style.display = "flex";
      lightboxImage.src = img.src;
      lightboxImage.alt = img.alt;
    });
  });

  closeBtn.addEventListener("click", () => overlay.style.display = "none");
  overlay.addEventListener("click", e => { if (e.target === overlay) overlay.style.display = "none"; });

});


